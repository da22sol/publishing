import { Route, Routes } from "react-router-dom";
import "./index.css";
import { ROUTE_ARR } from "./routes";
import MainPage from "./pages/main/main";
function App() {
  return (
    <>
      <MainPage /> 
    </>
  );
}

export default App;
