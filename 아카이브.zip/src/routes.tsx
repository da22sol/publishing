
import MainPage from './pages/main/main'
export const ROUTE = {
  MAIN: {
    path: '/',
    link: '/',
    element: MainPage,
  }
}

export const ROUTE_ARR = Object.values(ROUTE);